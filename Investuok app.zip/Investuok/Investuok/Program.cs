﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using OfficeOpenXml;

namespace Investuok
{
    class Program
    {
        static ExcelPackage ex, db;
        static void Main(string[] args)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial; // Reikalauja nurodyti kokią licenciją naudoti
            var info = ParseTickers();                                  // db.xlsx įmonių tickeriai (reikalingi skaičiuojant TTM P/E)

            while (true)
            {
                Console.WriteLine("Įveskite termino pabaigos datą formatu yyyy-mm-dd: ");
                DateTime dt = DateTime.ParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime mt = dt.AddMonths(-1).AddDays(1);  // prieš mėnesį
                DateTime yt = dt.AddMonths(-12).AddDays(1); // prieš metus
                Console.WriteLine($"Laikotarpis: {yt.ToString("yyyy.MM.dd")} - {mt.ToString("yyyy.MM.dd")} - {dt.ToString("yyyy.MM.dd")}");

                string path = Download(mt, dt);         // Atsiunčia statistinį failą iš nasdaq už paskutines 30/31 dienų.
                BidirectList<string> columns = ParseColumns();             // Gauna visus stulpelius
                object[,] data = ReadData();                                // Nuskaito visus langelius nuo antros eilutės
                var entries = Transform(columns, data);                     // Transformuoja pirminius duomenis į struktūrizuotą pavidalą
                SetExtremePoints(ref entries, yt, dt); // Randa metinius ekstremumo taškus
                ProcessPE(ref entries, info);           // Suskaičiuoja kiekvienos įmonės P/E
                entries = entries.OrderBy(o => o.Company).ToList(); // Išrikiuoja pagal abėcėlę.
                Console.WriteLine("| {4,3} | {0,-31} | {1,-16} | {2,-10} | {3,-15} | {5,-10} | {6,-10} | {7, -10} | {8,-10} | {9,-10}", "Bendrovė", "Kaina " + dt.ToString("yyyy.MM.dd"), "Pokytis, %", "Apyvarta, Eur", "Nr.", "Mak. kaina", "Data", "Min. kaina", "Data", "Pokytis, %*");
                Console.WriteLine(new string('-', 150));
                for (int i = 0; i < entries.Count; i++)
                {
                    var entry = entries[i];
                    Console.WriteLine("| {4,3} | {0,-31} | {1,16:F3} | {2,10:P2} | {3,15:F2} | {5,10:F3} | {6,10} | {7,10:F3} | {8,10} | {9,10:P2}", entry.Company, entry.LastPrice, entry.MonthlyChange, entry.Turnover, i + 1, entry.YearMaxPrice, entry.YearMaxDate.ToShortDateString(), entry.YearMinPrice, entry.YearMinDate.ToShortDateString(), entry.YearlyChange);
                }
                Console.WriteLine(new string('-', 150));
                Console.WriteLine("| {4,3} | {0,-31} | {1,-16} | {2,10:P2} | {3,15:F2} | {5,-10} | {6,-10} | {7, -10} | {8,-10} | {9,10:P2}", "Vidurkis", "", entries.Average(o => o.MonthlyChange), "-", "-", "-", "-", "-", "-", entries.Average(o => o.YearlyChange));

                string save = $"OUTPUT ({mt.ToShortDateString()}-{dt.ToShortDateString()}).CSV";
                SaveAsCSV(save, entries);           // Išsaugoja į csv.
                Console.WriteLine("Rezultatai išsaugoti pavadinimu "+save+"\r\n");
                File.Delete(path);      // ištrina parsisiųstą nasdaq statistinį failą.

            }
        }
        static string Download(DateTime start, DateTime end)
        {
            string save = $"{(start.Ticks + end.Ticks)}.xlsx";
            string a = $"https://nasdaqbaltic.com/statistics/en/statistics/download?filter=1&preset=m&start={start.ToShortDateString()}&end={end.ToShortDateString()}";
            using (WebClient wc = new WebClient())
                wc.DownloadFile(a, save);
            ex = new ExcelPackage(new FileInfo(save));
            return save;
        }
        static BidirectList<string> ParseColumns()
        {
            var ws = ex.Workbook.Worksheets.FirstOrDefault();
            var bl = new BidirectList<string>();
            for (int c = 1; c <= ws.Dimension.End.Column; c++)
                bl.Add(ws.Cells[1, c].Text);

            return bl;
        }

        // db.xlsx pradinis nuskaitymo etapas
        static BidirectList<string> ParseTickers()
        {
            db = new ExcelPackage(new FileInfo("db.xlsx"));
            BidirectList<string> bl = new BidirectList<string>();
            var ws = db.Workbook.Worksheets.FirstOrDefault();
            for (int r = 2; r <= ws.Dimension.End.Row; r++)
                bl.Add(ws.Cells[r, 1].Text);
            return bl;
        }

        // nuskaito nasdaq MĖNESINĮ statistinį failą
        static object[,] ReadData()
        {
            var ws = ex.Workbook.Worksheets.FirstOrDefault();
            object[,] arr = new object[ws.Dimension.Rows - 1, ws.Dimension.Columns];
            for (int r = 2; r <= ws.Dimension.Rows; r++)
                for (int c = 1; c < ws.Dimension.Columns; c++)
                    arr[r - 2, c - 1] = ws.Cells[r, c].Value;
            return arr;
        }

        // transformuoja nuskaitytus duomenis į tinkamus duomenų tipus ir įdeda į klasę.
        static List<Entry> Transform(BidirectList<string> cols, object[,] data)
        {
            List<Entry> entries = new List<Entry>();
            // indeksai
            int segment = cols["List/segment"];
            int ticker = cols["Ticker"];
            int isin = cols["ISIN"];
            int company = cols["Company"];
            int lastPrice = cols["Last price"];
            int openPrice = cols["Open price"];
            int turnover = cols["Turnover"];
            int market = cols["Market"];
            for (int i = 0; i < data.GetLength(0); i++)
            {
                if (data[i, turnover] == null) continue;
                if (
                    ((string)data[i, segment] == "Baltic Main List" || (string)data[i, segment] == "Baltic Secondary List")
                    && (double)data[i, turnover] >= 0)
                {
                    Entry e = new Entry()
                    {
                        Company = (string)data[i, company],
                        Ticker = (string)data[i, ticker],
                        ISIN = (string)data[i, isin],
                        LastPrice = (double)data[i, lastPrice],
                        MonthAgoPrice = (double)data[i, openPrice],
                        Turnover = (double)data[i, turnover],
                        Market = (string)data[i,market]
                    };
                    e.MonthlyChange = e.LastPrice / e.MonthAgoPrice - 1;
                    entries.Add(e);
                }
        
            }
            return entries;
        }
        
        // Atsiunčia kiekvienos įmonės METINĘ kainų istoriją, suranda max ir min taškus, įdeda juos į klasę.
        static void SetExtremePoints(ref List<Entry> entries, DateTime start, DateTime end)
        {
            string path, save;
            List<PricePair> pricePairs = new List<PricePair>((int)((end-start).TotalDays*5/7));
            
            using (WebClient wc = new WebClient())
            {
                for (int i = 0; i < entries.Count; i++)
                {
                    pricePairs.Clear();
                    path = $"https://nasdaqbaltic.com/statistics/en/instrument/{entries[i].ISIN}/trading/chart_price_download?start={start.ToShortDateString()}&end={end.ToShortDateString()}&historical=0";
                    save = $"{entries[i].ISIN}.xlsx";
                    wc.DownloadFile(path, save);
                    ExcelPackage history = new ExcelPackage(new FileInfo(save));
                    ExcelWorksheet ew = history.Workbook.Worksheets.FirstOrDefault();
                    for(int r = 3; r <= ew.Dimension.Rows; r++) {
                        object d = ew.Cells[r, 1].Value;
                        object lp = ew.Cells[r, 9].Value;
                        if (d == null || lp == null) continue;
                        pricePairs.Add(new PricePair() { Date = DateTime.FromOADate((double)d), Price = (double)lp });
                    }
                    var min = pricePairs.Aggregate((i1, i2) => i1.Price < i2.Price ? i1 : i2);
                    var max = pricePairs.Aggregate((i1, i2) => i1.Price > i2.Price ? i1 : i2);
                    entries[i].YearAgoPrice = pricePairs.LastOrDefault().Price;
                    entries[i].YearlyChange = entries[i].LastPrice / entries[i].YearAgoPrice - 1;
                    entries[i].YearMinPrice = min.Price;
                    entries[i].YearMaxPrice = max.Price;
                    entries[i].YearMinDate = min.Date;
                    entries[i].YearMaxDate = max.Date;
                    Console.WriteLine(i+1+" Apdorota "+entries[i].Company);
                    File.Delete(save);
                }
            }
        }

        // Papildomas funkcionalumas - apskaičiuoja kainos ir 12 mėnesių (4 paskutiniai ketvirčiai db.xlsx faile) pelno santykį. 
        static void ProcessPE(ref List<Entry> entries, BidirectList<string> tickers)
        {
            var ws = db.Workbook.Worksheets.FirstOrDefault();
            for (int i = 0; i < entries.Count; i++)
            {
                try
                {
                    int index = tickers[entries[i].Ticker] + 2;
                    double cap = entries[i].LastPrice * (double)ws.Cells[index, 2].Value;
                    double profit = 0;
                    for (int j = ws.Dimension.End.Column - 3; j <= ws.Dimension.End.Column; j++)
                    {
                        object o = ws.Cells[index, j].Value;
                        if (o == null) continue;
                        profit += (double)ws.Cells[index, j].Value;
                    }
                    entries[i].TTM_PE = cap / profit;
                } catch
                {
                    entries[i].TTM_PE = 0;
                }
            }
        }

        // Išsaugoja į csv failą tokia pačia tvarka, kaip excelio šablono stulpelių išdėstymas. Tereikia atsidarius pažymėti ir įklijuoti į excelį kaip "123" (beformačiu) režimu.
        static void SaveAsCSV(string path, List<Entry> entries)
        {
            var mtops = entries.OrderByDescending(o => o.MonthlyChange).ToList();
            var ytops = entries.OrderByDescending(o => o.YearlyChange).ToList();
            using (StreamWriter sw = new StreamWriter(path,false,Encoding.UTF8))
            {
                sw.WriteLine("Bendrovė;Kaina;Pokytis;Apyvarta;Aukščiausia kaina;Data;Žemiausia kaina;Data;Pokytis;TTM P/E");
                foreach (var e in entries)
                    sw.WriteLine($"{e.Company}, {e.Ticker};{e.LastPrice};{e.MonthlyChange};{e.Turnover};{e.YearMaxPrice};{e.YearMaxDate.ToShortDateString()};{e.YearMinPrice};{e.YearMinDate.ToShortDateString()};{e.YearlyChange};{e.TTM_PE}");
                sw.WriteLine($"Vidurkis;;{entries.Average(o=>o.MonthlyChange)};;;;;;{entries.Average(o => o.YearlyChange)}");
                sw.WriteLine();

                sw.WriteLine("Pavadinimas;Kaina;Mėnesinis pokytis;TTM P/E");
                for (int i = 0; i < 5; i++)
                    sw.WriteLine($"{mtops[i].Company}, {mtops[i].Ticker};{mtops[i].LastPrice};{mtops[i].MonthlyChange};{mtops[i].TTM_PE}");

                for (int i = mtops.Count-5; i < mtops.Count; i++)
                    sw.WriteLine($"{mtops[i].Company}, {mtops[i].Ticker};{mtops[i].LastPrice};{mtops[i].MonthlyChange};{mtops[i].TTM_PE}");

                sw.WriteLine();

                sw.WriteLine("Pavadinimas;Kaina;Metinis pokytis;TTM P/E");
                for (int i = 0; i < 5; i++)
                    sw.WriteLine($"{ytops[i].Company}, {ytops[i].Ticker};{ytops[i].LastPrice};{ytops[i].YearlyChange};{ytops[i].TTM_PE}");
                for (int i = mtops.Count - 5; i < mtops.Count; i++)
                    sw.WriteLine($"{ytops[i].Company}, {ytops[i].Ticker};{ytops[i].LastPrice};{ytops[i].YearlyChange};{ytops[i].TTM_PE}");


            }
        }
        
        
    }
    class Entry
    {
        public string Company { get; set; }
        public string ISIN { get; set; }
        public string Ticker { get; set; }
        public string Market { get; set; }
        public double LastPrice { get; set; }
        public double MonthAgoPrice { get; set; }
        public double YearAgoPrice { get; set; }
        public double YearMinPrice { get; set; }
        public double YearMaxPrice { get; set; }
        public DateTime YearMinDate { get; set; }
        public DateTime YearMaxDate { get; set; }
        public double MonthlyChange { get; set; }
        public double YearlyChange { get; set; }
        public double Turnover { get; set; }
        public double TTM_PE { get; set; }
    }
    class PricePair
    {
        public double Price { get; set; }
        public DateTime Date { get; set; }
    }
    class BidirectList<T>
    {
        int counter = 0;
        int offset = 0;
        Dictionary<int, T> a = new Dictionary<int, T>();
        Dictionary<T, int> b = new Dictionary<T, int>();
        public int Count => counter - offset;
        public T this[int key] => a[key];
        public int this[T value] => b[value];
        public BidirectList(int offset = 0) // KONSTRUKTORIUS
        {
            this.offset = offset;
            counter = offset;
        }
        public void Add(T val)
        {
            a.Add(counter, val);
            b.Add(val, counter);
            counter++;
        }
        public T[] GetValues() => a.Values.ToArray();
        public int[] GetKeys() => b.Values.ToArray();
        public KeyValuePair<int, T>[] GetKeyValuePairs() => a.ToArray();
    }
}
